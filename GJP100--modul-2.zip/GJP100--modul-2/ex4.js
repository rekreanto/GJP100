/*
 * Funktioner för att beräkna enkel aritmetik
 */

function sum(x,y){
  return x+y;
}
function product(x,y){
  return x*y;
}