/*  UTILITY FUNCTIONS FOR EPHEMERAL STATE MACHINE
*   ============================================= 
* The helper functions are designed based on Harels original papaer from 1987 and some 
* adaptations by Henning Sato von Rosen done during GJP100, spring 2020. The adaptations 
* aim to make the machine naturally and readably embeddable into a JavaScript code base, thus 
* obliviating the need for a large state machine library.
*
* TOC
*  1. EPHEMERAL STATE CONSTRUCTOR 
*  2.  
*  3. 
*  4. 
*   
*   
*
*
*/


/*******************************
 * EPHEMERAL STATE CONSTRUCTOR *
 *******************************
    *
    * WITH LIFE CYCLE ANLAYSIS 
    *
    */ 

  // Create an *Ephemeral State* based on the insight that a transiton is not
  // the same as the state function; a state function must be wrapped in SEND
  // in order to work as a state function.
  // Also note that
  // State(<boundary-actions>)::(<state>)

                                            // EPHEMERAL STATE LIFE CYCLE
                                            // ==========================
const State = (...entryActions) =>          // :: <state constructor>
(...xs) => {                                // ENTERING STATE 
console.log("ENTERING with args ", xs);             
let exitActions = entryActions              //   Perform Entry Actions 
                    .map(act => act(...xs));
                                            // ... STATE IS ALIVE ...
return (stateFunction) => {                 // EXITING STATE
  exitActions                               //  Perform Exit actions    
    .map(act => act(...xs));  
  return stateFunction(...xs);              // GIVE args to the next state funciton
}                                 
};




/*************************
 * BEHAVIOUR CONSTRUCTOR *
 *************************
    *
    * WITH LIFE CYCLE ANLAYSIS 
    *
    */

// on EVENT creates a *Behaviour* by binding a transiton to en event
// for the duration of a state
// onEVENT supports modals
// a Modal is an ordinary Boundary Action, such as changing the label/icon
// of a button for the duration of a state
//
// onEVENT(<string>)(<element>)(<transition>, <modal>*)


                                                // BEHAVIOUR LIFE CYCLE
                                                // ====================  
const onEVENT = (eventName) => (element) =>     //
    (transition, ...entryModals) =>             // :: <behavior>
      (...xs) => {                              // ON ENTRY:
                                                //   Establish behaviour
        element.addEventListener(eventName, transition);
                                                //   Establish Modals
        let exitModals = entryModals.map(mdl => mdl(elements[0])(...xs));
                                                //   BEHAVE until state exits
        return (...ys) => {                     // ON EXIT:    
                                                //   Remove behaviour
            element.removeEventListener(eventName, transition);
          exitModals.map(mdl => mdl(...ys));    //   Remove Modals
        }
      } 
   
    // onCLICK(<element>)(<transition>, <modal>*)::(<behaviour>)
    const onCLICK = onEVENT('click');




/**********************
 * MODAL LCONSTRUCTOR *
 **********************
    *
    * WITH LIFE CYCLE ANLAYSIS 
    *
    */

// modalTEXT is a MODAL
// a modal can be used as a normal Boundary Action:: , if given 
// Type as a Modal:
//   modalTEXT(<show>)::(<target elem>)(<state args>)(state args)
// Type as a Bounday Action
// modalTEXT(<show>)(<target elem>)::(<state args>)(state args)

// MODAL LIFE CYCLE
// ================     
console.log("hej");         
const modalTEXT = (show) =>                  // :: <modal>
    (elem)  =>                        // :: <boundary action>
    (...xs) => {                      // ENTER modality
      let orig = elem.textContent;       //   Save original modality          
      elem.textContent = show(...xs);    //   Set temporary modality
                                         // ... BE MODAL ...
      return (...ys) => {                // EXIT modality
        elem.textContent = orig;         //   Revert to original modality
      }
    }


/************************
 * THE BOUNDARY ACTIONS *
 ************************/

    // onTIMEOUT(<duration in ms>)(<transition>)::(<entry state>)->(<exit state>)
    const onTIMEOUT = (duration) => (transition) => (...xs) => { 
      // entry action: set timeout
      let timerId = setTimeout(() => transition(...xs), duration); 
      return (...ys) => {
        // exit action: delete timeout
        clearTimeout(timerId);
      }
    }



    const modalCLASS = (...classes) => (element) => {
      // entry action
      element.classList.add(...classes)
      return (...ys) => {
        //exit action
        element.classList.remove(...classes)
      }
    }